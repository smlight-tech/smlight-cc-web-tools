import asyncio
import logging

from .firmware import FirmwareFile
from .flasher import Flasher

_LOGGER = logging.getLogger(__name__)
logging.basicConfig(level=logging.DEBUG)


async def main():
    flasher = Flasher("/dev/ttyUSB0")
    await flasher.async_init()
    path = "./znp_LP_CC1352P7_smlight_NOSWAP.hex"
    data = bytearray()
    with open(path, "rb") as f:
        data = bytearray(f.read())
    firmware = FirmwareFile(buffer=data)
    flasher.set_firmware(firmware)
    await flasher.connect()
    await flasher.flash()


if __name__ == "__main__":
    asyncio.run(main())
